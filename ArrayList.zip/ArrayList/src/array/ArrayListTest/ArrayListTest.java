package array.ArrayListTest;

import java.util.ArrayList;

public class ArrayListTest {
    
    public static void main(String[] args) {
        
        ArrayList<String> list = new ArrayList<String>();
        //<>안에 자료형 명시 안해도 되지만 나중에 사용할 때 최상위 타입인 object로 되기 때문에 타입을 지정해주는 casting을 해야함.
        list.add("aaa");
        list.add("bbb");
        list.add("ccc");
        
        for (String s : list) {
            System.out.println(s);
        }
        /* for(int i=0; i<list.size(); i++) {
               System.out.println(list.get(i)); 
        }
        이것과 같음
        .size()가 . 앞에 있는 ArrayList의 요소 개수 반환
        .get(i)가 . 앞에 있는 ArrayList의 i 위치에 있는 요소 반환
        
        또한 ArrayList에서는 list[i] 형태의 index 연산자, 순수 배열을 선언했을 때의 연산자는 제공하지 않음
        */
        
        
    }
}