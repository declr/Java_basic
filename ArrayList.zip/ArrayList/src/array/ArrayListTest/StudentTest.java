package array.ArrayListTest;

public class StudentTest {
    
    public static void main(String[] args) {
        
        Student 김현빈 = new Student(202220715, "김현빈");
        
        김현빈.addSubject("수학", 100);
        김현빈.addSubject("국어", 100);
        
        김현빈.showStudentInfo();
        
    }
    
}