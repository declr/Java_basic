package array;
//객체 배열, 예시는 책 이름과 저자
/*배열 복사
System.arraycopy(array1, 0, array2, 1, 4); 이런 식으로 복사를 한다. 
의미는 (복사할 배열, 복사할 첫 위치, 대상 배열, 붙여넣을 위치 그거부터 시작됨, 복사할 요소 개수 몇 개 복사할 건지)

또한 객체배열을 복사할 경우 주소를 복사해서 넣는 것이기 때문에 array1의 멤버들을 바꿔도 array2에 똑같이 적용된다.
이것을 원하지 않을 경우 array2의 인스턴스를 생성한 후 멤버변수를 for 반복문을 통한 getter를 이용해서 적용하면 된다.
*/

/*향상된 for문 (enhanced for loop), 배열을 끝까지 다 돌릴 때 사용
for(변수 : 배열) {
    반복 실행문;
}

Ex)
String[] strArr = {"Java", "Android", "C"};

for(String s : strArr) {
    System.out.println(s);
}
정수 배열도 가능
*/


public class ObjectArray{
    
    private String bookName;
    private String author;
    
    public ObjectArray() {}
    public ObjectArray(String bookName, String author) {
        this.bookName = bookName;
        this.author = author;
    }
    
    public String getBookName() {
        return bookName;
    }
     public String getAuthor() {
        return author;
    }
     public void setBookName() {
        this.bookName = bookName;
    }
     public void setAuthor() {
        this.author = author;
    }
    
    public void showBookInfo() {
        System.out.println(bookName + "," + author);
    }
    
    
    public static void main(String[] args) {
        
        ObjectArray[] library = new ObjectArray[5];
        
        library[0] = new ObjectArray("태백산맥1", " 조정래");
        library[1] = new ObjectArray("태백산맥2", " 조정래");
        library[2] = new ObjectArray("태백산맥3", " 조정래");
        library[3] = new ObjectArray("태백산맥4", " 조정래");
        library[4] = new ObjectArray("태백산맥5", " 조정래");
        
        for(int i = 0; i<library.length; i++) {
            System.out.println(library[i]);
        }
        
        for(int i = 0; i<library.length; i++) {
            library[i].showBookInfo();
        }
        
        
        
        ObjectArray[] library2 = new ObjectArray[5];
        
        System.arraycopy(library, 0, library2, 0, 5);
        for(int i = 0; i<library2.length; i++) {
            library2[i].showBookInfo();
        }
        
    }
}