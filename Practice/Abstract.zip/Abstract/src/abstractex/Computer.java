package abstractex;

/*추상 클래스
추상 메서드가 있는 클래스는 추상 클래스가 돼야 함.
추상 메서드가 없더라도 abstract 사용을 통해 상속만을 위해 추상클래스로 만들 수 있음.

int add(int x, int y) {} 이런식으로 돼 있는 것은 추상 메서드가 아님. 그저 구현부 {} 안에 내용이 없는 것 뿐

new 예약어를 통해 인스턴스 생성 안됨. 추상 메서드를 호출 했을 때 구현될 내용이 없기 때문.

하지만 추상클래스에서도 Computer c = new LapTop();과 같이 형변환을 사용할 수 있음.
*/

public abstract class Computer {
    
    public abstract void display();
    public abstract void typing();
    
    public void turnOn() {
        System.out.println("전원을 켭니다.");
    }
    public void turnOff() {
        System.out.println("전원을 끕니다.");
    }
    
    
}