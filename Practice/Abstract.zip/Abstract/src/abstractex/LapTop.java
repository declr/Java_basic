package abstractex;

public abstract class Laptop extends Computer {
    
    public void display() {
        System.out.println("LapTop display()");
    }
    
    
}