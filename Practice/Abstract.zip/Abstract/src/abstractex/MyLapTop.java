package abstractex;

public abstract class MyLaptop extends Laptop {
    
    public void typing() {
        System.out.println("MyLaptop typing()");
    }
    
    
}