package array.ArrayListTest;

public class Subject {
    
    private String name;
    private int scorePoint;
    
    public String getname() {
        return name;
    }
     public int getscorePoint() {
        return scorePoint;
    }
     public void setname(String name) {
        this.name = name;
    }
     public void setscorePoint(int scorePoint) {
        this.scorePoint = scorePoint;
    }
}