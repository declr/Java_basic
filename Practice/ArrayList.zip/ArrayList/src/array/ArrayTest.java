package array;

public class ArrayTest {

    public static void main(String[] args) {
        
        /*
        int numbers[];
        numbers[] = {1, 2, 3};
        
        or 
        
        int numbers[] = new int[3] {1, 2, 3};
        
        이건 안됨
        
        그리고 초기화 따로 안하면 
        int는 0
        float 0.0
        객체배열은 null로 초기화 됨
        */
        
        int numbers[] = new int[] {3, 1, 2};
        System.out.println(numbers[0]);
        
        
        
        int[] numbers1 = new int[3];
        for (int i=0; i < numbers1.length; i++) {
            numbers1[i] = i+3;
            
        }
        for (int i = 0; i < numbers1.length; i++) {
            System.out.print(numbers1[i]);    
        }
        
        System.out.println();
        
        int[] numbers2 = {1, 2, 3}; //이것도 자료 갯수 정해진 거임
        for (int i = 0; i < numbers2.length; i++) {
            System.out.println(numbers2[i]);    
        }
    
    }

}
