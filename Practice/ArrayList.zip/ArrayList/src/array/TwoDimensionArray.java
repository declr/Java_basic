package array;

public class TwoDimensionArray {
 
    public static void main(String[] args) {
        
        int[][] arr = new int [2][3];
        System.out.println(arr.length);
        //길이를 물어보면 행의 길이를 출력한다.
        System.out.println(arr[0].length);
        /*arr[0]의 길이를 물어보면 0번째 행 자체의 길이, 
        0번째 행이 몇 열을 가지고 있는지 출력한다.*/
        
        int[][] arr2 = {{1,2,3},{4,5,6}};
        for(int i=0; i < arr2.length; i++) {
            
            for(int j=0; j < arr2[i].length; j++) {                
                System.out.println(arr2[i][j]);
            }
        }
  
    }
}