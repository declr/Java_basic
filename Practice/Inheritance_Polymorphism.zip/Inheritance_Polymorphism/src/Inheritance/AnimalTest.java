package Inheritance;

import java.util.ArrayList;

class Animal{    
    public void move() {
        System.out.println("동물이 움직입니다.");
    }
}

class Human extends Animal{    
    public void move() {
        System.out.println("사람이 두발로 걷습니다.");
    }
    
    public void readBook() {
        System.out.println("사람이 책을 읽습니다.");
    }
}

class Tiger extends Animal{    
    public void move() {
        System.out.println("호랑이가 네발로 뜁니다.");
    }
    
    public void hunting() {
        System.out.println("호랑이가 사냥을 합니다.");
    }
}

class Eagle extends Animal{    
    public void move() {
        System.out.println("독수리가 하늘을 납니다.");
    }
    
    public void flying() {
        System.out.println("하늘을 날아갑니다.");
    }
}

public class AnimalTest {
    
    public static void main(String[] args) {
        
        AnimalTest test = new AnimalTest();
        test.moveAnimal(new Human()); 
        test.moveAnimal(new Tiger());
        test.moveAnimal(new Eagle());
        
        Animal[] animalList = new Animal[3];
        animalList[0] = new Human();
        ArrayList<Animal> animals = new ArrayList<Animal>();
        animals.add(new Tiger());
        
    }
    
    
    public void moveAnimal(Animal animal) {
        
        // Animal animal 이 코드는 Animal a = new Human() 이 코드와 같은 의미를 가진다.
        animal.move();
        
        /* Human h = (Human)animal;
        이런 식으로 상위 타입이 하위 타입이 될 수 있다. Human h = animal은 안됨.
        그런데 Tiger가 들어왔는데 저런 식으로 할당되면 안되기 때문에 instanceof라는 키워드가 있다.
        이것을 사용하는 걸 다운캐스팅이라 부른다.
        */
        
        // 좋은 방법이 아니므로 오버라이딩으로 해결이 안될 때 주로 다운캐스팅을 사용한다.
        
        /*다운캐스팅 주 사용처(Object 사용)
        Object는 모든 클래스의 상위 클래스로 Object로 변환될 수 있는 경우가 많다.
        또한 어떤 메서드를 불렀을 때 반환값이 Object로 넘어올 수도 있다.
        그때는 원래 형으로 반환할 때 다운캐스팅 종종 사용함.
        */
        
        if (animal instanceof Human) { //animal의 인스턴스 자료형이 Human형이라면
            Human human = (Human)animal; // 인스턴스 animal을 Human형으로 다운캐스팅
            human.readBook();
        }
        else if (animal instanceof Tiger) {
            Tiger tiger = (Tiger)animal;
            tiger.hunting();
        }
        else if (animal instanceof Eagle) {
            Eagle eagle = (Eagle)animal;
            eagle.flying();
        }
        else {
            System.out.println("지원되지 않는 기능입니다.");
        }
        
        
        
    }
}