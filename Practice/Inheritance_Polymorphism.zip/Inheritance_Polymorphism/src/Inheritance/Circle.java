package Inheritance;

public class Circle {
    
    Point point;
    
    private int radius;
    
    public Circle() {
        point = new Point();
    }
    
}