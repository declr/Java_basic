package Inheritance;

public class CustomerTest1 {
    
    public static void main(String[] args) {
        
        /*Customer customerLee = new Customer();
        customerLee.setCustomerID(10100);
        customerLee.setCustomerName("Lee");*/
        
        VIPCustomer customerKim = new VIPCustomer(10101, "김현빈", 100);
        /* Customer customerKim = new VIPCustomer();
        이런 게 가능하다. 이것을 업캐스팅(상위 클래스로의 묵시적 형 변환)이라고 한다.
        상위 클래스 형으로 변수를 선언하고 하위 클래스 인스턴스를 생성하는 것이다. 
        하위 클래스가 상위 클래스의 타입을 내포하고 있기에 가능하다.
        
        이럴 경우 VIP생성자의 호출로 인스턴스는 모두 생성되지만,
        타입이 Customer이므로 접근 가능 부위는 Customer의 변수와 메서드 까지이다. */
        
        customerKim.bonusPoint = 1000;
        
        // System.out.println(customerLee.showCustomerInfo());
        System.out.println(customerKim.showCustomerInfo());
    }
}