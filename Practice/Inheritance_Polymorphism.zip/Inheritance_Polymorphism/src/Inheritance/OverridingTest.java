package Inheritance;

public class OverridingTest {
    
    public static void main(String[] args) {
        
        /* 
        Customer customerLee = new Customer(100010, "Lee");
        int price = customerLee.calcPrice(10000);
        System.out.println("지불 금액은" + price + "이고 " + customerLee.showCustomerInfo());
        
        VIPCustomer customerKim = new VIPCustomer(100011, "김현빈", 100);
        price = customerKim.calcPrice(10000);
        System.out.println("지불 금액은" + price + "이고 " + customerKim.showCustomerInfo());
        */
        
        Customer customerWho = new VIPCustomer(100010, "who", 100);
        int price = customerWho.calcPrice(10000);
        System.out.println("지불 금액은" + price + "이고, " + customerWho.showCustomerInfo());
        /*
        가상 메서드(virtual method)
        자바는 기본적으로 모든 메서드가 가상메서드이다. 
        이 경우는 타입과 상관없이 실제 생성된 인스턴스의 메서드가 호출된다.
        
        이런 식으로 업캐스팅 했을 경우 참조 변수는 타입의 것만 참조할 수 있다.
        그런데 메서드가 재정의 되었다면 재정의 된 메서드가 호출되어 사용된다. 
        
        인스턴스는 생성될 때마다 힙 메모리에 새롭게 잡히고,
        코드 구성의 경우도 코드 영역에 저장되며 새롭게 잡히는 건 맞지만.
        한 마디로, 타입은 일반 인스턴스는 VIP이면 VIP calcPrice가 새롭게 재정의 됐는데 2개 따로 있으니까 혼란스럽네? 이런 게 아니고 최근 정의로 덮어 씌워지는 느낌.
        물론 일반 Customer calcPrice부르면 일반으로 됨.
        */
        
        
    }
}