package Inheritance;

public class Point {
    
    private int x;
    private int y;
    
    public int getx() {
        return x;
    }
    public void setx(int x) {
        this.x = x;
    }
    public int gety() {
        return x;
    }
    public void sety(int y) {
        this.y = y;
    }

}
