package Inheritance;

public class VIPCustomer extends Customer {
    
    int agentID;
    double saleRatio;
    
    public VIPCustomer() {
        
        customerGrade = "VIP";
        bonusRatio = 0.05;
        saleRatio = 0.1;
    }
    
    public VIPCustomer(int customerID, String customerName, int agentID) {
        
        /* compile 단계에서 super(); 적용됨. super는 하위클래스가 상위 클래스에 대한 주소를 가짐.
        이는 상위 클래스 default constructer를 호출하는 코드임.
        그렇기 때문에 하위 클래스를 호출할 때 상위 클래스가 먼저 호출됨. 
        그렇기 때문에 상위 클래스의 멤버 변수들이 메모리를 잡을 수 있게 되고
        하위 클래스는 이를 사용할 수 있게 된다. */
        
        /* 하위 클래스의 생성자에서는 무조건 상위 클래스의 생성자가 호출돼야 함. 
        아무것도 없는 경우에 super(); 넣어주는 거임. 
        만약 상위 클래스의 기본 생성자가 없으면 명시적으로 하위 클래스에서 상위 클래스를 호출해야함. */
        
        super(customerID, customerName);
        customerGrade = "VIP";
        bonusRatio = 0.05;
        saleRatio = 0.1;
        this.agentID = agentID;
        
        //System.out.println("VIPCustomer(int, String) 호출");
    } 
    
    public int calcPrice(int price) {
        
        /* 오버라이딩
        부모 자식 상속 관계에 있는 클래스에서 상위 클래스의 메서드를 하위 클래스에서 재정의 하는 것.
        
        오버로딩은 같은 이름의 메서드가 여러개 있는 것. */
        bonusPoint += price*bonusRatio;
        return price - (int)(price*saleRatio);
    }
    
    public String showCustomerInfo() {
        
        return super.showCustomerInfo() + " 담당 상담원 아이디는 " + agentID + "입니다.";
        
    }
}