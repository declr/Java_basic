package project;

public class Main {
    
    public static void main(String[] args) {
        int num1 = 10;
        int num2=5;
        
        Calc calc = new CompleteCalc();
        
        calc.description();
        
        int[] arr = {1,2,3,4,5};
        int sum = Calc.total(arr);
        System.out.println(sum);
        
    }
    
    
}