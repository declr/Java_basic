package interfaceex;

/* 인터페이스
extends 클래스 상속의 경우에는 하나만 가능하지만 implements 인터페이스 상속의 경우에는 여러개 가능.

인터페이스는 추상 메서드와 상수로만 이루어져있다.
프로그램이 제공하는 기능을 명시적으로 선언한다.
구현된 코드가 없기에 인스턴스 생성이 불가하다. 

인터페이스에 선언한 메서드는 public abstract를 쓰지 않아도 컴파일 과정에서 자동으로 추상메서드가 된다.
선언한 변수는 컴파일 과정에서 값이 변하지 않는 상수가 된다. public static final(이걸 통해 상수 선언을 할 수 있음)을 쓰지 않아도 된다.

Calc calc = new CompleteCalc();
이런 식으로 묵시적 형 변환 가능. Calc 인터페이스를 CompleteCalc 클래스의 상위클래스로 봐도 됨.
*/

public interface Calc {
    
    double PI = 3.14;
    int ERROR = -999999999;
    
    int add(int num1, int num2);
    int substract(int num1, int num2);
    int times(int num1, int num2);
    int divide(int num1, int num2);

   

}
