package scheduler;

public interface Scheduler {
    
    void getNextCall();
    void sendCallToAgent();
    
}