package project;

public class Main {
    
    public static void main(String[] args) {
      
        Customer customer = new Customer();
        
        Buy buyer = customer;
        buyer.buy();
        
        Sell seller = customer;
        seller.sell();
        
        customer.buy();
        customer.sell();
        
        customer.order();
        seller.order();
        buyer.order();
        
    }
    
}