package project;

public class MyClass implements MyInterface {
    
    public void x() {
        System.out.println("x()");
    }
    
    public void y() {
        System.out.println("y()");
    }
    
    public void myMethod() {
        System.out.println("myMethod()");
    }
    
    public static void main(String[] args) {
        
        MyClass myClass = new MyClass();
        myClass.y();
        myClass.x();
        myClass.myMethod();
        
        X xClass = myClass;
        xClass.x();
        
    }
}