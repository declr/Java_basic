package project;

public interface MyInterface extends X,Y {
    
    void myMethod();
}