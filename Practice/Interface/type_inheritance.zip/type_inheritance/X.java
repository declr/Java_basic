package project;

public interface X {
    
    void x();
}