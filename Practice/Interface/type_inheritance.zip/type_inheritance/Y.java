package project;

public interface Y {
    
    void y();
}