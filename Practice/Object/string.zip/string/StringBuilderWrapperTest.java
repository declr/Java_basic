package string;

/* 
이 함수들은 내부 변경이 가능한 char[]를 변수로 가지고 있다. 그러므로 원래 주소값이 가리키는 것이 변경될 수 있다.

StringBuilder와 StringBuffer의 차이는 builder는 단일쓰레드에서 권장되고 후자는 멀티 쓰레드에서 권장된다.
buffer가 문자열이 안전하게 변경되도록 해주는 반면 builder는 그렇지 않다. 하지만 멀티스레드 프로그램이 아니라면 
락을 안 걸어주는 builder가 속도가 더 빠르기 때문에 builder를 사용하는 게 좋다. */

public class StringBuilderWrapperTest {
    
    public static void main(String[] args) {
        
        String str1 = new String("java");
        
        System.out.println(System.identityHashCode(str1));
        
        StringBuilder buffer = new StringBuilder(str1);
        System.out.println(System.identityHashCode(buffer));
        
        buffer.append((" and"));
        buffer.append((" android"));
        System.out.println(System.identityHashCode(buffer));
        System.out.println(buffer);
        
        str1 = buffer.toString();
        //이렇게 하면 문자의 배열을 문자열 형태로 다시 대입가능.
        System.out.println(str1);
        System.out.println(System.identityHashCode(str1));
        
        
        // Wrapper 클래스
        // 언박싱은 객체형을 기본형으로 만드는 것 num.intValue사용, 오토박싱은 기본형을 객체형으로 바꾸는 것 Integer.valueOf(num)사용.
        Integer i = 100;//new 예약어를 사용하지 않고도 객체형으로 사용가능
        
    }
    
    
}