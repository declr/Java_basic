package string;

/* String 생성자의 매개변수로 문자열을 생성하면 각각의 객체가 생기고 매개변수를 위한 메모리가 할당된다. 
생성자를 이용하지 않고 바로 문자열 상수를 가리키는 경우에는 문자열 상수의 메모리 주소를 가리키게 되므로 이 방식으로 같은 문자열을 다른 변수에 대입하면 주소깂이 같다.

한번 생성된 문자열은 불변한다.
그러므로 두 개의 문자열을 연결하면 새로운 인스턴스가 생성된다. 
즉, str1에 어떤 문자열을 대입하고 여기에 str2를 연결하면 str1은 원래의 문자열을 변형시키지 않고 
str1과 str2를 연결한 새로운 문자열을 가리킨다. str1에 원래 대입됐던 문자열의 주소를 가리키지 않고 새로운 문자열의 주소를 가리킨다.
그렇기 때문에 문자열 연결을 계속하면 gabage가 많이 생길 수 있다.
*/

public class StringTest {

    public static void main(String[] args) {
        
        /*String str1 = new String("abc");
        String str2 = new String("abc");
        System.out.println(str1 == str2);
        
        String str3 = "abc";
        String str4 = "abc";
        System.out.println(str3 == str4); */
        
        String str1 = new String("java");
        String str2 = new String("android");
        System.out.println(str1.hashCode());
        System.out.println(System.identityHashCode(str1));
        // String의 경우 hashcode() 함수를 재정의 했다. 그렇기 때문에 hashcode() 함수는 주소값을 반환하지 않고 클래스 고유의 값을 반환한다.
        
        str1 = str1.concat(str2);
        System.out.println(str1);
        System.out.println(str1.hashCode());
        System.out.println(System.identityHashCode(str1));
        
    }

}
