package object;

/*일반적으로 equals()메소드는 "두 인스턴스의 주소 값을 비교하여 boolean 값"을 반환한다. 물리적 동일성을 판단하는 것이다.
String과 Integer은 그 클래스 내부에서 재정의돼 있기 때문에 다르게 나온다. 논리적 동일성을 볼 수 있다. 문자열이 같은지 숫자가 같은지 등을 반환한다는 것이다.

일반적으로 hashCode()메소드는 객체의 특정 정보를 매개변수 값으로 넣으면 그 객체가 저장되어야 할 위치나 저장된 해시 테이블 주소를 반환한다. 10진수로.
자바에서는 두 인스턴스가 같다면 hashCode()메서드에서 반환하는 해시 코드값도 같아야 한다. equals()메서드를 재정의 했다면 논리적으로 동일하다면 hashCode()메서드도 재정의 해야한다.
String과 Integer은 그 클래스 내부에서 재정의돼 있기 때문에 다르게 나온다. String은 같은 문자열이라면 같은 해시 코드값을 반환하고 Integer는 정수값을 반환한다.
*/

class Student{
    int studentID;
    String studentName;
    
    Student(int studentID, String studentName) {
        this.studentID=studentID;
        this.studentName=studentName;
    }
    
    public boolean equals(Object obj) {
        if(obj instanceof Student) {
            Student std = (Student)obj;
            if(studentID == std.studentID) return true;
            else return false;
        }
        return false;    
    }
    
    public int hashCode() {
        return studentID;
    }
    
}

public class EqualsHashTest {
    public static void main(String[] args) {
        String str1 = new String("test");
        String str2 = new String("test");
        
        /*System.out.println(str1==str2);
        System.out.println(str1.equals(str2));*/
        
        Student std1 = new Student(10001, "Tomas");
        Student std2 = new Student(10001, "Tomas");
        
        System.out.println(std1==std2);
        System.out.println(std1.equals(std2));
        
        System.out.println(std1.hashCode());
        System.out.println(std2.hashCode());
        System.out.println(System.identityHashCode(std2));
        
        System.out.println(str1.hashCode());
        System.out.println(str2.hashCode());
    }
}