package object;
/* cloneable 인터페이스는 마커 인터페이스 딱히 구현해줘야 하는 게 없음. 
*/
class Point{
    int x;
    int y;
    
    Point(int x, int y){
        this.x=x;
        this.y=y;
    }
    
    public String toString() {
        return "x=" + x + "," +"y=" +y;
    }
}

class Circle implements Cloneable{
    
    Point point;
    private int radius;
    
    public Circle(int x, int y, int radius) {
        point = new Point(x, y);
        this.radius=radius;
    }
    
    public String toString() {
        return "원점은 " +this.point + "이고, 반지름은 " +radius + "입니다.";
    }//this.point의 경우 원래는 주소인데 그게 toString으로 불러오는 거라 이 경우 오버라이딩해 준 것으로 써짐.
    
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

public class ObjectCloneTest {

    public static void main(String[] args) throws CloneNotSupportedException {
        
        Circle circle = new Circle(10, 20, 5);
        Circle cloneCircle = (Circle)circle.clone();
        
        System.out.println(System.identityHashCode(circle));
        System.out.println(System.identityHashCode(cloneCircle));
        
        System.out.println(circle);
        System.out.println(cloneCircle);
    }

}
